import * as anchor from "@coral-xyz/anchor";

describe("staking", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  it("Initialize program", async () => {
    // placeholder
  });
});