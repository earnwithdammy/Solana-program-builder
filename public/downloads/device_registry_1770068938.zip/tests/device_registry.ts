import * as anchor from "@coral-xyz/anchor";

describe("device_registry", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  it("Initialize registry", async () => {
    // placeholder
  });
});